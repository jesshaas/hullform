#define BUILD_DATE "Build date 13-Aug-2010"
#define VERSION "Version 9.12"
